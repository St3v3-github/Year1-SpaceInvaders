//
// Created by Steven on 04/03/2022.
//

#ifndef SPACEINVADERSSFML_SHIP_H
#define SPACEINVADERSSFML_SHIP_H

#include <SFML/Graphics.hpp>
#include <iostream>

class Ship
{
 public:
  Ship(sf::RenderWindow &window);
  ~Ship();

  bool init();
  void update(float dt);
  void render();
  void keyPressed(sf::Event event);
  void keyReleased(sf::Event event);
  void spawn();

  sf::RenderWindow &window;

    float ship_speed = 500;

  sf::Sprite ship;
  sf::Texture ship_texture;
  sf::Vector2f ship_direction = {0,0};

  bool is_on_left;
};

#endif // SPACEINVADERSSFML_SHIP_H
