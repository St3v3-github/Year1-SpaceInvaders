//
// Created by Steven on 04/03/2022.
//

#include "Alien.h"
#include "cmath"

Alien::Alien()
{

}

void Alien::addTexture(sf::Texture& texture)
{
  sprite.setTexture(texture);
}

void Alien::move(float dt, sf::RenderWindow& window)
{
  if (alien_move_right)
  {
    sprite.move(1.0f * alien_speed * dt, 0);
  }

  else
  {
    sprite.move(-1.0f * alien_speed * dt, 0);
  }

  if (
    (sprite.getPosition().x >= window.getSize().x - sprite.getGlobalBounds().width) ||
    (sprite.getPosition().x <= 0))
  {
    alien_move_right = !alien_move_right;
  }

  switch (current_movetype)
  {
    case (OG):
    {
      if (
        (sprite.getPosition().x >= window.getSize().x - sprite.getGlobalBounds().width) ||
        (sprite.getPosition().x <= 0))
      {
        sprite.setPosition(sprite.getPosition().x, sprite.getPosition().y + 50);
      }
    }
    break;

    case (Gravity):
    {
      sprite.move(0, 25 * dt);
    }
    break;

    case (Quadratic):
    {
      float spriteX = (sprite.getPosition().x - window.getSize().x / 2) / 75;
      sprite.move(0, pow(spriteX, 2) / 75);
    }
    break;

    case (Sine):
    {
      sprite.move(0, sin(sprite.getPosition().x / 100 * 3));
    }
    break;
  }
}

void Alien::setIsVisible(bool value)
{
  is_visible = value;
}

bool Alien::getIsVisible()
{
  return is_visible;
}

void Alien::vanquish()
{
  setIsVisible(false);
  for (int i = 0; i < grid_size; i++)
  {
    for (int j = 0; j < grid_size; j++)
    {
      sprite.setPosition(10 + 2000 * i, 100 + 2000 * j);
      sprite.move(0, 0);
    }
  }
}
void Alien::reset()
{
  setIsVisible(true);

}
bool Alien::isAlienMoveRight() const
{
  return alien_move_right;
}
void Alien::setAlienMoveRight(bool alienMoveRight)
{
  alien_move_right = alienMoveRight;
}
