//
// Created by Steven on 25/02/2022.
//

#ifndef SPACEINVADERSSFML_GAMEOVERMENU_H
#define SPACEINVADERSSFML_GAMEOVERMENU_H

#include <iostream>
#include <SFML/Graphics.hpp>

class GameOverMenu
{
 public:
  GameOverMenu(sf::RenderWindow &window);
  ~GameOverMenu();

  bool init();
  void update(float dt);
  void render();
  void keyPressed(sf::Event event);

  sf::RenderWindow&window;

  sf::Font font;
  sf::Text gameOverTitleText;
  sf::Text gameOverWinText;
  sf::Text gameOverLoseText;
  sf::Text gameOverPlayOption;
  sf::Text gameOverQuitOption;

  bool gameOverPlaySelected = true;

  int score = 0;
  sf::Text ScoreText;
  std::string score_str;
};

#endif // SPACEINVADERSSFML_GAMEOVERMENU_H
