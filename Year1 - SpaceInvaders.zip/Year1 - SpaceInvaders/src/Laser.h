//
// Created by Steven on 04/03/2022.
//

#ifndef SPACEINVADERSSFML_LASER_H
#define SPACEINVADERSSFML_LASER_H

#include <iostream>
#include <SFML/Graphics.hpp>

class Laser
{

 public:
  Laser();
  void move(float dt);
  void laserCheck();
  void reset();

  sf::Sprite sprite;

  void addTexture(sf::Texture& texture);

  bool getIsVisible();
  void setIsVisible(bool value);
  bool shooting = false;

 private:
  bool is_visible = true;
  float speed = 750;

};

//class Laser
//{
// public:
//  Laser(sf::RenderWindow &window);
//  ~Laser();
//
//  bool init();
//  void update(float dt);
//  void render();
//  void spawn();
//
//  sf::RenderWindow &window;
//
//  sf::Sprite laser;
//  sf::Texture laser_texture;
//
//  float laser_speed = 750;
//  bool laser_shoot = false;
//};



#endif // SPACEINVADERSSFML_LASER_H
