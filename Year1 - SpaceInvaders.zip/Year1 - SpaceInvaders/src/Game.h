
#ifndef SPACEINVADERS_GAME_H
#define SPACEINVADERS_GAME_H

#include "Alien.h"
#include "GameOverMenu.h"
#include "Laser.h"
#include "MainMenu.h"
#include "Ship.h"
#include "Vector2.h"
#include <SFML/Graphics.hpp>

class Game
{
 public:
  Game(sf::RenderWindow& window);
  ~Game();
  bool init();
  void update(float dt);
  void render();
  void keyPressed(sf::Event event);
  void keyReleased(sf::Event event);
  bool collisionCheck(sf::Sprite sprite1, sf::Sprite sprite2);
  void gameReset();
  void mouseClicked(sf::Event event);


  enum StateEnum
  {
    mainMenu,
    gamePlay,
    gameOver
  };

  StateEnum current_state = mainMenu;

 private:
  sf::RenderWindow& window;

  MainMenu *main_menu = nullptr;
  GameOverMenu *game_over_menu = nullptr;
  Ship* ship = nullptr;

  sf::Sprite background;
  sf::Texture background_texture;

  sf::Font font;
  sf::Text TitleText;
  sf::Text QuitPrompt;

  sf::Text Instructions;

  //Alien Things
  int grid_size = 5;
  Alien aliens [25];
  sf::Texture alien_texture_1;
  sf::Texture alien_texture_2;
  sf::Texture alien_texture_3;
  sf::Texture alien_texture_4;
  sf::Texture alien_texture_5;

  //Laser things
  const static int laser_array_size = 10;
  Laser Lasers[laser_array_size];
  sf::Texture laser_texture;

};

#endif // SPACEINVADERS_GAME_H
