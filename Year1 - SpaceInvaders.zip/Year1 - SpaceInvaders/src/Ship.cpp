//
// Created by Steven on 04/03/2022.
//

#include "Ship.h"

Ship::Ship(sf::RenderWindow &window): window(window)
{
  init();
}

Ship::~Ship()
{

}

bool Ship::init()
{
  if (!ship_texture.loadFromFile("Data/Images/SpaceShooterRedux/PNG/playerShip2_red.png"))
  {
    std::cout << "The Ship Texture didn't load in :( \n";
  }
  ship.setTexture(ship_texture);
  ship.setScale(0.75,0.75);
  ship.setPosition((window.getSize().x /2) - (ship.getGlobalBounds().width/2), (875 - ship.getGlobalBounds().height));

  return true;
}

void Ship::update(float dt)
{
  if (ship.getPosition().x > (window.getSize().x - ship.getGlobalBounds().width))
  {
    ship.move(-2 * ship_speed * dt, 0);
  }

  if (ship.getPosition().x < 0)
  {
    ship.move(2 * ship_speed * dt, 0);
  }

  else
  {
    ship.move(ship_direction.x * ship_speed * dt, 0);
  }
}

void Ship::render()
{
  window.draw(ship);
}

void Ship::keyPressed(sf::Event event)
{
  if (event.key.code == sf::Keyboard::A)
  {
    ship_direction.x = -1;
  }

  if (event.key.code == sf::Keyboard::D)
  {
    ship_direction.x = 1;
  }
}

void Ship::keyReleased(sf::Event event)
{
  if ((event.key.code == sf::Keyboard::A) || (event.key.code == sf::Keyboard::D))
  {
    ship_direction.x = 0;
  }
}

void Ship::spawn()
{
  ship.setPosition((window.getSize().x /2) - (ship.getGlobalBounds().width/2), (875 - ship.getGlobalBounds().height));
}
