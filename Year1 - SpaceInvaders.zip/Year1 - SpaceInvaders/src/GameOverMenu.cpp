//
// Created by Steven on 25/02/2022.
//

#include "GameOverMenu.h"

GameOverMenu::GameOverMenu(sf::RenderWindow &window): window(window)
{
  init();
}

GameOverMenu::~GameOverMenu()
{

}

bool GameOverMenu::init()
{
  // init Font
  if (!font.loadFromFile("Data/Fonts/OpenSans-Bold.ttf"))
  {
    std::cout << "The Font didn't load in :( \n";
  }

  gameOverTitleText.setString("Space Invaders");
  gameOverTitleText.setFont(font);
  gameOverTitleText.setCharacterSize(40);
  gameOverTitleText.setFillColor(sf::Color(240, 240, 240));
  gameOverTitleText.setPosition(30, 30);

  gameOverWinText.setString("You Win!");
  gameOverWinText.setFont(font);
  gameOverWinText.setCharacterSize(100);
  gameOverWinText.setFillColor(sf::Color(240, 240, 240));
  gameOverWinText.setPosition(((window.getSize().x / 2) - (gameOverWinText.getGlobalBounds().width) / 2),300);

  gameOverLoseText.setString("Game Over :(");
  gameOverLoseText.setFont(font);
  gameOverLoseText.setCharacterSize(100);
  gameOverLoseText.setFillColor(sf::Color(240, 240, 240));
  gameOverLoseText.setPosition(((window.getSize().x / 2) -(gameOverLoseText.getGlobalBounds().width) / 2),300);


  gameOverPlayOption.setString("Replay?");
  gameOverPlayOption.setFont(font);
  gameOverPlayOption.setCharacterSize(40);
  gameOverPlayOption.setFillColor(sf::Color(240, 240, 240));
  gameOverPlayOption.setPosition(((window.getSize().x / 2) - (gameOverPlayOption.getGlobalBounds().width)),450);

  gameOverQuitOption.setString("Quit");
  gameOverQuitOption.setFont(font);
  gameOverQuitOption.setCharacterSize(40);
  gameOverQuitOption.setFillColor(sf::Color(240, 240, 240));
  gameOverQuitOption.setPosition(((window.getSize().x / 2) + (gameOverQuitOption.getGlobalBounds().width) * 0.5),450);

  score_str = std::to_string(score);
  ScoreText.setString("Points:  " + score_str);
  ScoreText.setFont(font);
  ScoreText.setCharacterSize(40);
  ScoreText.setFillColor(sf::Color(240, 240, 240));
  ScoreText.setPosition(800, 30);

}

void GameOverMenu::update(float dt)
{
  score_str = std::to_string(score);
  ScoreText.setString("Points:  " + score_str);
}

void GameOverMenu::render()
{
  if (score == 25)
  {
    window.draw(gameOverWinText);
  }

  else
  {
    window.draw(gameOverLoseText);
  }

  window.draw(gameOverTitleText);
  window.draw(gameOverPlayOption);
  window.draw(gameOverQuitOption);
  window.draw(ScoreText);
}

void GameOverMenu::keyPressed(sf::Event event)
{
  if ((event.key.code == sf::Keyboard::A) || (event.key.code == sf::Keyboard::D))
  {
    gameOverPlaySelected = !gameOverPlaySelected;

    if (gameOverPlaySelected)
    {
      gameOverPlayOption.setString(">Replay? ");
      gameOverQuitOption.setString("  Quit");
    }

    else
    {
      gameOverPlayOption.setString("Replay? ");
      gameOverQuitOption.setString(" >Quit");
    }
  }
}