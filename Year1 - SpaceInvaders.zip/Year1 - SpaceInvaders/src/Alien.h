//
// Created by Steven on 04/03/2022.
//

#ifndef SPACEINVADERSSFML_ALIEN_H
#define SPACEINVADERSSFML_ALIEN_H

#include <SFML/Graphics.hpp>
#include <iostream>

class Alien
{
 public:
  Alien();
  bool init();
  void move(float dt, sf::RenderWindow& window);
  void vanquish();
  void reset();

  enum Type {one, two, three, four, five};
  sf::Sprite sprite;

  enum MoveType {OG, Gravity, Quadratic, Sine};
  MoveType current_movetype = OG;

  void addTexture(sf::Texture& texture);

  bool getIsVisible();
  void setIsVisible(bool value);

 private:

  bool is_visible = true;

  float alien_speed = 350;
  bool alien_move_right = true;

 public:
  void setAlienMoveRight(bool alienMoveRight);

 public:
  bool isAlienMoveRight() const;

 private:
  //  //Alien Things
  int grid_size = 5;
//  Alien aliens [25];
//  sf::Texture alien_texture_1;
//  sf::Texture alien_texture_2;
//  sf::Texture alien_texture_3;
//  sf::Texture alien_texture_4;
//  sf::Texture alien_texture_5;

};

#endif // SPACEINVADERSSFML_ALIEN_H
