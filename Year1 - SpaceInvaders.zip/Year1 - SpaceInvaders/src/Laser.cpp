//
// Created by Steven on 04/03/2022.
//

#include "Laser.h"

Laser::Laser()
{

}

void Laser::addTexture(sf::Texture& texture)
{
  sprite.setTexture(texture);
}

void Laser::setIsVisible(bool value)
{
  is_visible = value;
}

bool Laser::getIsVisible()
{
  return is_visible;
}

void Laser::move(float dt)
{
  if (shooting)
  {
    sprite.move(0, -1.0f * speed * dt);
    laserCheck();
  }
}
void Laser::laserCheck()
{
  if (sprite.getPosition().y + sprite.getGlobalBounds().height < 0)
  {
    reset();
  }
}
void Laser::reset()
{
  shooting = false;
  sprite.setPosition(-1000,-1000);
}

//Laser::Laser(sf::RenderWindow &window): window(window)
//{
//  init();
//}
//
//Laser::~Laser()
//{
//
//}
//
//bool Laser::init()
//{
//  if (!laser_texture.loadFromFile("Data/Images/SpaceShooterRedux/PNG/Lasers/laserGreen06.png"))
//  {
//    std::cout << "The Laser Texture didn't load in :( \n";
//  }
//  laser.setTexture(laser_texture);
//  laser.setScale(1.5, 1);
//  laser.setPosition(0,1200);
//  return false;
//}
//
//void Laser::update(float dt)
//{
//  if (laser_shoot)
//  {
//    laser.move(0,-1.0f * laser_speed * dt);
//  }
//
//  else
//  {
//    laser.move(0,0);
//  }
//}
//
//void Laser::render()
//{
//  window.draw(laser);
//}