#include "Alien.h"
#include "Game.h"
#include <iostream>

Game::Game(sf::RenderWindow& game_window): window(game_window)
{
  srand(time(nullptr));

  main_menu = new MainMenu(game_window);
  game_over_menu = new GameOverMenu(game_window);
  ship = new Ship(game_window);
}

Game::~Game()
{
  delete main_menu;
  delete game_over_menu;
  delete ship;
}

bool Game::init()
{
  if (!font.loadFromFile("Data/Fonts/OpenSans-Bold.ttf"))
  {
    std::cout << "The Font didn't load in :( \n";
  }

  TitleText.setString("Space Invaders");
  TitleText.setFont(font);
  TitleText.setCharacterSize(40);
  TitleText.setFillColor(sf::Color(240, 240, 240));
  TitleText.setPosition(30, 30);

  QuitPrompt.setString("Q to Quit");
  QuitPrompt.setFont(font);
  QuitPrompt.setCharacterSize(25);
  QuitPrompt.setFillColor(sf::Color(240, 240, 240));
  QuitPrompt.setPosition(875, 950);

  Instructions.setString("A/D to Play/Quit, Space to select \nArrow Keys to Choose Enemy Movement \nA/D to move ship, Space to shoot \n ");
  Instructions.setFont(font);
  Instructions.setCharacterSize(25);
  Instructions.setFillColor(sf::Color(240, 240, 240));
  Instructions.setPosition(10, 900);


  if (!background_texture.loadFromFile("Data/Images/SpaceShooterRedux/Backgrounds/black.png"))
  {
    std::cout << "The Background didn't load in :( \n";
  }

  background.setTexture(background_texture);
  background.setScale(4,4);

  //Alien Array
  if (
    !alien_texture_1.loadFromFile("Data/Images/SpaceShooterRedux/PNG/Enemies/enemyBlack1.png") ||
    !alien_texture_2.loadFromFile("Data/Images/SpaceShooterRedux/PNG/Enemies/enemyBlack2.png") ||
    !alien_texture_3.loadFromFile("Data/Images/SpaceShooterRedux/PNG/Enemies/enemyBlack3.png") ||
    !alien_texture_4.loadFromFile("Data/Images/SpaceShooterRedux/PNG/Enemies/enemyBlack4.png") ||
    !alien_texture_5.loadFromFile("Data/Images/SpaceShooterRedux/PNG/Enemies/enemyBlack5.png"))
  {
    std::cout << "A ship Texture didn't load in :( \n";
  }

  for (int i = 0; i < grid_size; i++)
  {
    for (int j = 0; j < grid_size; j++)
    {
      if ((i * grid_size + j) % 5 == 0)
      {
        aliens[i * grid_size + j].addTexture(alien_texture_1);
      }

      else if ((i * grid_size + j) % 5 == 1)
      {
        aliens[i * grid_size + j].addTexture(alien_texture_2);
      }

      else if ((i * grid_size + j) % 5 == 2)
      {
        aliens[i * grid_size + j].addTexture(alien_texture_3);
      }

      else if ((i * grid_size + j) % 5 == 3)
      {
        aliens[i * grid_size + j].addTexture(alien_texture_4);
      }

      else if ((i * grid_size + j) % 5 == 4)
      {
        aliens[i * grid_size + j].addTexture(alien_texture_5);
      }

      aliens[i * grid_size + j].sprite.setPosition(10 + 100 * i, 100 + 100 * j);
      aliens[i * grid_size + j].sprite.setScale(0.75, 0.75);
    }
  }

//laser array
  if (!laser_texture.loadFromFile("Data/Images/SpaceShooterRedux/PNG/Lasers/laserGreen06.png"))
      {
        std::cout << "The Laser Texture didn't load in :( \n";
      }

  for (int j = 0; j < laser_array_size; j++)
  {
    Lasers[j].addTexture(laser_texture);
    Lasers[j].reset();
  }

  return true;
}

void Game::update(float dt)
{
  switch (current_state)
  {
    case gamePlay:
    {
      ship->update(dt);
      game_over_menu->update(dt);

      for (int i = 0; i < grid_size * grid_size; i++)
      {
        aliens[i].move(dt, window);
      }

      for (int j = 0; j < laser_array_size; j++)
      {
        if (Lasers[j].shooting)
        {
          Lasers[j].move(dt);
        }
      }

      for (int i = 0; i < grid_size * grid_size; i++)
      {
        for (int j = 0; j < laser_array_size; j++)
        {
          if (collisionCheck(Lasers[j].sprite, aliens[i].sprite))
          {
            Lasers[j].reset();
            aliens[i].vanquish();
            game_over_menu -> score = game_over_menu -> score + 1;
            std::cout <<"score = "<< game_over_menu -> score << std::endl;
          }

          if (collisionCheck(ship->ship, aliens[i].sprite))
          {
            current_state = gameOver;
          }
        }
      }

      if (game_over_menu -> score == 25)
      {
        current_state = gameOver;
      }

    }
  }
}

void Game::render()
{
  switch (current_state)
  {
    case mainMenu:
    {
      main_menu->render();
      window.draw(Instructions);
    }
    break;

    case gamePlay:
    {
      window.draw(background);
      window.draw(Instructions);
      ship->render();

      for (int i = 0; i < grid_size * grid_size; i++)
      {
        if (aliens[i].getIsVisible())
        {
          window.draw(aliens[i].sprite);
        }
      }

      for (int j = 0; j < laser_array_size; j++)
      {
        window.draw(Lasers[j].sprite);
      }

      window.draw(TitleText);
      window.draw(QuitPrompt);
      window.draw(game_over_menu->ScoreText);

    }
    break;

    case gameOver:
    {
      game_over_menu->render();
      window.draw(Instructions);
    }
    break;
  }
}

void Game::keyPressed(sf::Event event)
{
  switch (current_state)
  {
    case mainMenu:
    {
     main_menu->keyPressed(event);
    }
    break;

    case gamePlay:
    {
      ship->keyPressed(event);

      if (event.key.code == sf::Keyboard::Q)
      {
        current_state = mainMenu;
        gameReset();
      }

      if (main_menu->GameType_Option == 1)
      {
        for (int i = 0; i < grid_size * grid_size; i++)
        {
          aliens[i].current_movetype = aliens[i].OG;
        }
      }

      if (main_menu->GameType_Option == 2)
      {
        for (int i = 0; i < grid_size * grid_size; i++)
        {
          aliens[i].current_movetype = aliens[i].Gravity;
        }
      }

      if (main_menu->GameType_Option == 3)
      {
        for (int i = 0; i < grid_size * grid_size; i++)
        {
          aliens[i].current_movetype = aliens[i].Quadratic;
        }
      }

      if (main_menu->GameType_Option == 4)
      {
        for (int i = 0; i < grid_size * grid_size; i++)
        {
          aliens[i].current_movetype = aliens[i].Sine;
        }
      }


    }
    break;

    case gameOver:
    {
      game_over_menu->keyPressed(event);
    }
    break;
  }
}

void Game::keyReleased(sf::Event event)
{
  switch (current_state)
  {
    case mainMenu:
    {
      if (event.key.code == sf::Keyboard::Space)
      {
        if (main_menu->mainMenuPlaySelected)
        {
          current_state = gamePlay;
        }

        else
        {
          window.close();
        }
      }
      break;

      case gamePlay:
      {
        ship->keyReleased(event);

        if (event.key.code == sf::Keyboard::Space)
        {
          for (int j = 0; j < laser_array_size; j++)
          {
            if (!Lasers[j].shooting)
            {
              Lasers[j].sprite.setPosition(
                ship->ship.getPosition().x +
                  ship->ship.getGlobalBounds().width / 2 -
                  Lasers[j].sprite.getGlobalBounds().width / 2,
                ship->ship.getPosition().y);
              Lasers[j].shooting = true;
              break;
            }
          }
        }
      }
      break;

      case gameOver:
      {
        if (event.key.code == sf::Keyboard::Space)
        {
          if (game_over_menu->gameOverPlaySelected)
          {
            current_state = mainMenu;
            gameReset();
          }

          else
          {
            window.close();
          }
        }
      }
      break;
    }
  }
}

bool Game::collisionCheck(sf::Sprite sprite1, sf::Sprite sprite2)
{
  if(
    sprite1.getPosition().x <= sprite2.getPosition().x + sprite2.getGlobalBounds().width &&
    sprite1.getPosition().x + sprite1.getGlobalBounds().width >= sprite2.getPosition().x &&
    sprite1.getPosition().y <= sprite2.getPosition().y + sprite2.getGlobalBounds().height &&
    sprite1.getPosition().y + sprite1.getGlobalBounds().height >= sprite2.getPosition().y)
  {
    return true;
  }
}

void Game::gameReset()
{
  game_over_menu->score = 0;
  ship->spawn();;

  for (int j = 0; j < laser_array_size; j++)
  {
    Lasers[j].reset();
  }

  for (int i = 0; i < grid_size; i++)
  {
    for (int j = 0; j < grid_size; j++)
    {
      aliens[i * grid_size + j].reset();
      aliens[i * grid_size + j].setAlienMoveRight(true);
      aliens[i * grid_size + j].sprite.setPosition(10 + 100 * i, 100 + 100 * j);

    }
  }

}
