//
// Created by Steven on 25/02/2022.
//

#include "MainMenu.h"

MainMenu::MainMenu(sf::RenderWindow &window): window(window)
{
  init();
}

MainMenu::~MainMenu()
{

}

bool MainMenu::init()
{
  // init Font
  if (!font.loadFromFile("Data/Fonts/OpenSans-Bold.ttf"))
  {
    std::cout << "The Font didn't load in :( \n";
  }

  mainMenuIntroText.setString("Space Invaders");
  mainMenuIntroText.setFont(font);
  mainMenuIntroText.setCharacterSize(100);
  mainMenuIntroText.setFillColor(sf::Color(240, 240, 240));
  mainMenuIntroText.setPosition(((window.getSize().x / 2) - (mainMenuIntroText.getGlobalBounds().width) / 2),300);

  mainMenuPlayOption.setString("Play");
  mainMenuPlayOption.setFont(font);
  mainMenuPlayOption.setCharacterSize(40);
  mainMenuPlayOption.setFillColor(sf::Color(240, 240, 240));
  mainMenuPlayOption.setPosition(((window.getSize().x / 2) - (mainMenuPlayOption.getGlobalBounds().width)),450);

  mainMenuQuitOption.setString("Quit");
  mainMenuQuitOption.setFont(font);
  mainMenuQuitOption.setCharacterSize(40);
  mainMenuQuitOption.setFillColor(sf::Color(240, 240, 240));
  mainMenuQuitOption.setPosition(((window.getSize().x / 2) + (mainMenuQuitOption.getGlobalBounds().width) * 0.5),450);

  OGOption.setString("OG");
  OGOption.setFont(font);
  OGOption.setCharacterSize(40);
  OGOption.setFillColor(sf::Color(240, 240, 240));
  OGOption.setPosition(100,650);

  GravityOption.setString("Gravity");
  GravityOption.setFont(font);
  GravityOption.setCharacterSize(40);
  GravityOption.setFillColor(sf::Color(240, 240, 240));
  GravityOption.setPosition(250,650);

  QuadraticOption.setString("Quadratic");
  QuadraticOption.setFont(font);
  QuadraticOption.setCharacterSize(40);
  QuadraticOption.setFillColor(sf::Color(240, 240, 240));
  QuadraticOption.setPosition(500,650);

  SineOption.setString("Sine");
  SineOption.setFont(font);
  SineOption.setCharacterSize(40);
  SineOption.setFillColor(sf::Color(240, 240, 240));
  SineOption.setPosition(800,650);


}

void MainMenu::update(float dt)
{

}

void MainMenu::render()
{
  window.draw(mainMenuIntroText);
  window.draw(mainMenuPlayOption);
  window.draw(mainMenuQuitOption);

  window.draw(OGOption);
  window.draw(GravityOption);
  window.draw(QuadraticOption);
  window.draw(SineOption);
}

void MainMenu::keyPressed(sf::Event event)
{
  if ((event.key.code == sf::Keyboard::A) || (event.key.code == sf::Keyboard::D))
  {
    mainMenuPlaySelected = !mainMenuPlaySelected;

    if (mainMenuPlaySelected)
    {
      mainMenuPlayOption.setString(">Play ");
      mainMenuQuitOption.setString("  Quit");
    }

    else
    {
      mainMenuPlayOption.setString("Play ");
      mainMenuQuitOption.setString(" >Quit");
    }
  }

  if (event.key.code == sf::Keyboard::Left)
  {
    GameType_Option = GameType_Option - 1;
    if (GameType_Option < 1)
    {
      GameType_Option = 4;
    }
  }

  if (event.key.code == sf::Keyboard::Right)
  {
    GameType_Option = GameType_Option + 1;
    if (GameType_Option > 4)
    {
      GameType_Option = 1;
    }
  }

  if (GameType_Option == 1)
  {
    OGOption.setString(" > OG");
    GravityOption.setString(" Gravity");
    QuadraticOption.setString(" Quadratic");
    SineOption.setString(" Sine");
  }

  else if (GameType_Option == 2)
  {
    OGOption.setString(" OG ");
    GravityOption.setString(" > Gravity");
    QuadraticOption.setString(" Quadratic");
    SineOption.setString(" Sine");
  }

  else if (GameType_Option == 3)
  {
    OGOption.setString(" OG ");
    GravityOption.setString(" Gravity");
    QuadraticOption.setString(" > Quadratic");
    SineOption.setString(" Sine");
  }

  else if (GameType_Option == 4)
  {
    OGOption.setString(" OG ");
    GravityOption.setString("  Gravity");
    QuadraticOption.setString(" Quadratic");
    SineOption.setString("> Sine");
  }
}